'use client';

import React from 'react';
import { Participant } from '@/app/lib/types';
import { Button } from '@/components/ui/button';
import { Download, MapPin, Phone, Mail, Calendar, Clock } from 'lucide-react';

interface ReceiptGeneratorProps {
  participant: Participant;
}

export default function ReceiptGenerator({ participant }: ReceiptGeneratorProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-10">
      <div id="receipt-content" className="max-w-3xl mx-auto p-12 bg-[#faf9f6] border border-primary/10 shadow-inner rounded-xl relative overflow-hidden">
        {/* Artistic Background Flourish */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-secondary/5 rounded-full blur-3xl" />

        <div className="relative space-y-12">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <h3 className="text-3xl font-headline font-bold text-secondary">VisoRegistry</h3>
              <p className="text-[10px] tracking-[0.3em] uppercase text-primary font-bold">Official Registration Receipt</p>
            </div>
            <div className="text-right space-y-1 text-[10px] text-muted-foreground uppercase font-bold tracking-widest">
              <p className="flex items-center justify-end gap-1"><MapPin className="w-3 h-3" /> Accra, Ghana</p>
              <p className="flex items-center justify-end gap-1"><Mail className="w-3 h-3" /> concierge@visoregistry.com</p>
            </div>
          </div>

          {/* Training Info Summary */}
          <div className="bg-white/50 p-4 rounded-lg border border-primary/5 grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-[8px] uppercase tracking-widest text-muted-foreground font-bold">Training Date</p>
              <p className="text-xs font-bold text-secondary">22 Aug 2026</p>
            </div>
            <div>
              <p className="text-[8px] uppercase tracking-widest text-muted-foreground font-bold">Venue</p>
              <p className="text-xs font-bold text-secondary">Royal Fiesta Hotel</p>
            </div>
            <div>
              <p className="text-[8px] uppercase tracking-widest text-muted-foreground font-bold">Fee</p>
              <p className="text-xs font-bold text-secondary">GH₵ {participant.trainingCost.toLocaleString()}</p>
            </div>
          </div>

          {/* Main Info */}
          <div className="grid grid-cols-2 gap-12 py-8 border-y border-primary/5">
            <div className="space-y-6">
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Full Name</p>
                <p className="text-lg font-headline italic text-secondary">{participant.fullName}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Occupation</p>
                <p className="text-sm text-secondary">{participant.occupation}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Address</p>
                <p className="text-sm text-secondary">{participant.address}</p>
              </div>
            </div>
            <div className="space-y-6 text-right">
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Registration ID</p>
                <p className="font-mono text-sm text-primary font-bold">#VR-{participant.id.toUpperCase()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Date Issued</p>
                <p className="text-sm text-secondary">{new Date(participant.registrationDate).toLocaleDateString()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Payment Method</p>
                <p className="text-sm font-bold text-secondary">{participant.paymentMethod} {participant.otherPaymentMethod ? `(${participant.otherPaymentMethod})` : ''}</p>
              </div>
            </div>
          </div>

          {/* Financials */}
          <div className="space-y-4">
            <div className="flex justify-between items-center text-[10px] font-bold pb-2 border-b border-primary/10 uppercase tracking-[0.2em] text-muted-foreground">
              <span>Item Description</span>
              <span>Amount (GH₵)</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <div className="space-y-0.5">
                <p className="font-headline italic text-lg text-secondary">Advanced Beauty Certification</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">1-Day Intensive Training Program</p>
              </div>
              <span className="text-xl font-bold font-headline">{participant.trainingCost.toLocaleString()}</span>
            </div>
            <div className="pt-4 space-y-2 border-t border-primary/5">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">Amount Paid</span>
                <span className="font-bold text-primary italic">GH₵ {participant.amountPaid.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-lg pt-2">
                <span className="font-bold text-secondary uppercase tracking-widest text-xs">Balance Due</span>
                <span className="font-bold font-headline underline decoration-primary/30 underline-offset-8">GH₵ {participant.balanceDue.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Signature & Footer */}
          <div className="pt-10 relative">
            <div className="tear-line absolute top-0 left-0 w-full" />
            <div className="flex justify-between items-end pt-12">
              <div className="space-y-2">
                <p className="text-[9px] uppercase tracking-[0.3em] font-bold text-primary">Transaction Ref</p>
                <p className="text-xs font-mono bg-white px-4 py-2 rounded-lg border border-primary/5 shadow-sm inline-block">
                  {participant.paymentReference}
                </p>
              </div>
              <div className="text-right space-y-2">
                {participant.signature ? (
                  <img src={participant.signature} alt="Signature" className="h-12 ml-auto grayscale brightness-0 opacity-70" />
                ) : (
                  <div className="h-12 w-32 border-b border-muted-foreground/20" />
                )}
                <p className="text-[8px] uppercase tracking-[0.3em] text-muted-foreground font-bold">Authorized Signature</p>
              </div>
            </div>
            
            <div className="mt-12 text-center">
              <p className="text-[8px] uppercase tracking-[0.5em] text-muted-foreground font-bold">VisoRegistry Concierge Service</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-4 no-print">
        <Button onClick={handlePrint} className="gap-2 bg-secondary hover:bg-secondary/90 shadow-xl h-12 px-8 rounded-full">
          <Download className="w-4 h-4" /> Export Receipt
        </Button>
        <Button variant="outline" onClick={() => window.location.reload()} className="h-12 px-8 rounded-full border-primary/20 text-primary hover:bg-primary/5">
          New Registration
        </Button>
      </div>
    </div>
  );
}
