'use client';

import React, { useState, useMemo } from 'react';
import { Participant } from '@/app/lib/types';
import { useCollection, useFirestore } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Download, Users, TrendingUp, DollarSign, Loader2, ShieldAlert } from 'lucide-react';

export default function AdminConsole() {
  const [search, setSearch] = useState('');
  const db = useFirestore();

  // Create real-time listener for participants with memoized query
  const participantsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'participants'), orderBy('registrationDate', 'desc'));
  }, [db]);

  const { data: registrants, loading } = useCollection<Participant>(participantsQuery);

  const filtered = (registrants || []).filter(r => 
    r.fullName.toLowerCase().includes(search.toLowerCase()) ||
    (r.phone && r.phone.includes(search)) ||
    (r.email && r.email.toLowerCase().includes(search.toLowerCase()))
  );

  const totalRevenue = (registrants || []).reduce((acc, r) => acc + (Number(r.amountPaid) || 0), 0);
  const totalBalance = (registrants || []).reduce((acc, r) => acc + (Number(r.balanceDue) || 0), 0);

  if (loading) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-headline font-bold">Admin Console</h1>
          <p className="text-muted-foreground">Real-time management of participant applications and financial status.</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 shadow-md rounded-full px-6">
          <Download className="w-4 h-4 mr-2" /> Export Data (CSV)
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white border-none shadow-sm rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Total Participants</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-headline italic">{registrants?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-green-500" /> Live Data Stream Active
            </p>
          </CardContent>
        </Card>
        <Card className="bg-white border-none shadow-sm rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Collected Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-headline italic">GH₵ {totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Total payments received</p>
          </CardContent>
        </Card>
        <Card className="bg-white border-none shadow-sm rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Pending Balances</CardTitle>
            <ShieldAlert className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-headline italic text-destructive">GH₵ {totalBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Awaiting final payment</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white border-none shadow-sm overflow-hidden rounded-3xl">
        <CardHeader className="border-b border-primary/5 p-8">
          <div className="flex flex-col md:flex-row gap-6 justify-between items-center">
            <CardTitle className="text-xl font-headline italic">Registrant Data Warehouse</CardTitle>
            <div className="relative w-full md:w-96">
              <Search className="absolute left-4 top-3 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by name, email, phone..." 
                className="pl-12 h-12 border-none bg-muted/30 rounded-xl"
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead className="uppercase text-[10px] tracking-widest pl-8">Participant</TableHead>
                <TableHead className="uppercase text-[10px] tracking-widest">Experience</TableHead>
                <TableHead className="uppercase text-[10px] tracking-widest">Financials</TableHead>
                <TableHead className="uppercase text-[10px] tracking-widest">Reference</TableHead>
                <TableHead className="uppercase text-[10px] tracking-widest pr-8 text-right">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((r) => (
                <TableRow key={r.id} className="hover:bg-primary/5 transition-colors">
                  <TableCell className="pl-8">
                    <div className="space-y-0.5">
                      <p className="font-bold font-headline italic text-lg">{r.fullName}</p>
                      <p className="text-xs text-muted-foreground tracking-wider">{r.email}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-0.5 text-sm">
                      <p className="font-medium">{r.beautyExperience}</p>
                      <p className="text-xs text-primary font-bold uppercase tracking-widest">{r.specialization || 'Generalist'}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-0.5 text-sm">
                      <p>Paid: <span className="font-bold">GH₵ {(Number(r.amountPaid) || 0).toLocaleString()}</span></p>
                      {(Number(r.balanceDue) || 0) > 0 && <p className="text-[10px] text-destructive font-bold">Due: GH₵ {(Number(r.balanceDue) || 0).toLocaleString()}</p>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="text-[10px] bg-muted px-2 py-1 rounded border border-primary/10 font-mono">
                      {r.paymentReference}
                    </code>
                  </TableCell>
                  <TableCell className="pr-8 text-right">
                    <Badge variant={(Number(r.balanceDue) || 0) === 0 ? "default" : "secondary"} className="text-[10px] font-bold uppercase rounded-md tracking-tighter">
                      {(Number(r.balanceDue) || 0) === 0 ? "Cleared" : "Partial"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filtered.length === 0 && (
            <div className="py-24 text-center space-y-4">
              <Search className="w-16 h-16 text-muted-foreground/20 mx-auto" />
              <div className="space-y-1">
                <p className="text-muted-foreground italic font-headline text-xl">No matching records found</p>
                <p className="text-xs text-muted-foreground uppercase tracking-widest">Check your search terms or filters</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}