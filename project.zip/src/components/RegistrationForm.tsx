
'use client';

import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { 
  Calendar, MapPin, Clock, DollarSign, User, ShieldAlert, Sparkles, Loader2, 
  CheckCircle2, FileText, Smartphone, ChevronRight, ChevronLeft, Briefcase, 
  HeartHandshake, GraduationCap, CreditCard, Info, Award, Globe
} from 'lucide-react';
import { RegistrationFormData, Participant } from '@/app/lib/types';
import { processPaymentScreenshot } from '@/app/actions/registration';
import { cn } from '@/lib/utils';
import ReceiptGenerator from './ReceiptGenerator';
import { Progress } from '@/components/ui/progress';
import { useFirestore } from '@/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

const TRAINING_COST = 3500;
const TOTAL_STEPS = 4;

export default function RegistrationForm() {
  const db = useFirestore();
  const [formData, setFormData] = useState<RegistrationFormData>({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    dateOfBirth: '',
    occupation: '',
    ghanaCardId: '',
    ghanaCardDateOfIssue: '',
    ghanaCardPlaceOfIssue: '',
    ghanaCardExpiryDate: '',
    hasPreviousTraining: false,
    previousTrainingDetails: '',
    beautyExperience: '',
    specialization: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelationship: '',
    trainingCost: TRAINING_COST,
    amountPaid: 0,
    paymentMethod: 'Mobile Money',
    otherPaymentMethod: '',
    paymentReference: '',
    signature: '',
    declarationDate: new Date().toISOString().split('T')[0],
  });

  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedParticipant, setSubmittedParticipant] = useState<Participant | null>(null);
  const [activeStep, setActiveStep] = useState(1);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isSigning, setIsSigning] = useState(false);

  const balanceDue = Math.max(0, TRAINING_COST - formData.amountPaid);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingAI(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      const result = await processPaymentScreenshot(base64);
      setFormData(prev => ({ ...prev, paymentReference: result.reference }));
      setIsProcessingAI(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSignatureClear = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
      setFormData(prev => ({ ...prev, signature: '' }));
    }
  };

  const handleSignatureSave = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const dataUrl = canvas.toDataURL();
      setFormData(prev => ({ ...prev, signature: dataUrl }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (activeStep < TOTAL_STEPS) {
      setActiveStep(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    if (!db) return;

    setIsSubmitting(true);
    
    const participantData = {
      ...formData,
      balanceDue,
      registrationDate: new Date().toISOString(),
      createdAt: serverTimestamp(),
    };

    // Use non-blocking mutation with standard catch block as per guidelines
    addDoc(collection(db, 'participants'), participantData)
      .then((docRef) => {
        setSubmittedParticipant({
          ...participantData,
          id: docRef.id
        } as Participant);
        setIsSubmitting(false);
      })
      .catch(async (err: any) => {
        const permissionError = new FirestorePermissionError({
          path: 'participants',
          operation: 'create',
          requestResourceData: participantData,
        });
        errorEmitter.emit('permission-error', permissionError);
        setIsSubmitting(false);
      });
  };

  const startSigning = (e: React.MouseEvent | React.TouchEvent) => {
    setIsSigning(true);
    draw(e);
  };

  const stopSigning = () => {
    setIsSigning(false);
    handleSignatureSave();
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isSigning) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = ('touches' in e ? e.touches[0].clientY : e.clientY) - rect.top;

    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#333';
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  if (submittedParticipant) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4 animate-in fade-in zoom-in-95 duration-700">
        <Card className="border-none shadow-[0_32px_64px_-12px_rgba(0,0,0,0.14)] bg-white overflow-hidden rounded-3xl">
          <div className="bg-primary h-3 w-full" />
          <CardHeader className="text-center space-y-4 pt-16">
            <div className="mx-auto bg-green-50 w-24 h-24 rounded-full flex items-center justify-center border border-green-100 mb-4 shadow-inner">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <CardTitle className="text-5xl font-headline italic">Excellence Awaits</CardTitle>
            <CardDescription className="text-xl max-w-md mx-auto">
              Welcome to the cohort, {submittedParticipant.fullName.split(' ')[0]}. Your prestige membership is now active.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-12 px-12 pb-16">
            <div className="tear-line pb-12" />
            <ReceiptGenerator participant={submittedParticipant} />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-12 px-4 space-y-8">
      {/* Premium Header Branding */}
      <div className="w-full bg-secondary rounded-3xl overflow-hidden shadow-2xl border-b-4 border-primary">
        <div className="relative py-12 px-8 flex flex-col md:flex-row items-center justify-center gap-8 text-center md:text-left">
          <div className="relative flex items-center justify-center">
            <div className="w-24 h-24 rounded-full border-2 border-primary flex items-center justify-center text-primary font-headline text-5xl font-bold italic relative">
              ST
              <div className="absolute -right-2 top-0 bg-secondary p-1 rounded-full border border-primary/20">
                <Globe className="w-6 h-6 text-primary" />
              </div>
            </div>
          </div>
          
          <div className="space-y-2 max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-headline font-bold text-primary tracking-tight uppercase">
              Viso Facial Treatment
            </h2>
            <p className="text-lg md:text-xl font-headline italic text-white/90 tracking-[0.1em] uppercase">
              Training Program
            </p>
            <div className="flex items-center justify-center md:justify-start gap-4 py-2">
              <div className="h-px w-12 bg-primary/40" />
              <p className="text-sm font-bold text-white uppercase tracking-[0.4em]">
                Registration Form
              </p>
              <div className="h-px w-12 bg-primary/40" />
            </div>
          </div>
          <div className="absolute right-0 bottom-0 w-64 h-full bg-primary/10 rounded-tl-full blur-3xl -z-10" />
        </div>
      </div>

      <Card className="border-none shadow-sm bg-white rounded-2xl overflow-hidden p-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 divide-x divide-primary/10">
          <div className="flex items-center gap-4 pl-4 first:pl-0">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Training Date</p>
              <p className="text-sm font-bold text-secondary">22 August 2026</p>
            </div>
          </div>
          <div className="flex items-center gap-4 pl-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Training Venue</p>
              <p className="text-sm font-bold text-secondary">Accra Royal Fiesta Hotel</p>
            </div>
          </div>
          <div className="flex items-center gap-4 pl-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Duration</p>
              <p className="text-sm font-bold text-secondary">1-Day Intensive Program</p>
            </div>
          </div>
          <div className="flex items-center gap-4 pl-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Training Fee</p>
              <p className="text-sm font-bold text-secondary">GH₵ {TRAINING_COST.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </Card>

      <Card className="border-none shadow-[0_32px_64px_-12px_rgba(0,0,0,0.14)] bg-white rounded-3xl overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-4 bg-secondary p-12 text-white flex flex-col justify-between">
            <div className="space-y-10">
              <div className="space-y-2">
                <p className="text-primary font-bold text-xs uppercase tracking-[0.4em]">Step {activeStep} of {TOTAL_STEPS}</p>
                <h2 className="text-3xl font-headline italic font-bold">
                  {activeStep === 1 && "Personal Data"}
                  {activeStep === 2 && "Emergency & Experience"}
                  {activeStep === 3 && "Identification Details"}
                  {activeStep === 4 && "Payment & Declaration"}
                </h2>
              </div>

              <div className="space-y-6">
                {[1, 2, 3, 4].map((step) => (
                  <div key={step} className="flex items-center gap-4 group">
                    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-500", activeStep >= step ? "bg-primary border-primary" : "border-white/20")}>
                      {activeStep > step ? <CheckCircle2 className="w-5 h-5" /> : <span className="font-bold">{step}</span>}
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-sm font-bold tracking-wider uppercase">
                        {step === 1 && "Identity"}
                        {step === 2 && "Experience"}
                        {step === 3 && "Verification"}
                        {step === 4 && "Settlement"}
                      </p>
                      <p className="text-xs text-white/50">
                        {step === 1 && "Bio Data"}
                        {step === 2 && "Portfolio & Contact"}
                        {step === 3 && "Ghana Card KYB"}
                        {step === 4 && "Receipt & Signature"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-4">
                <div className="flex items-center gap-2 text-primary">
                  <GraduationCap className="w-5 h-5" />
                  <p className="text-xs font-bold uppercase tracking-widest">What You Will Learn</p>
                </div>
                <ul className="text-[11px] space-y-2 text-white/70 font-medium">
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Introduction to Viso Facial Treatment</li>
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Skin Analysis and Consultation</li>
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Proper Cleansing and Exfoliation Techniques</li>
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Facial Massage Procedures</li>
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Product Selection and Application</li>
                  <li className="flex gap-2"><CheckCircle2 className="w-3 h-3 text-primary shrink-0" /> Hands-on Practical Training</li>
                </ul>
              </div>
            </div>

            <div className="space-y-6 mt-12 pt-12 border-t border-white/10">
              <div className="space-y-1">
                <p className="text-[10px] uppercase tracking-widest text-primary font-bold">Total Investment</p>
                <p className="text-4xl font-headline font-bold">GH₵ {TRAINING_COST.toLocaleString()}</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-white/40">
                <ShieldAlert className="w-4 h-4" />
                <span>Verified by VisoRegistry Security</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 p-12">
            <Progress value={(activeStep / TOTAL_STEPS) * 100} className="h-1 mb-12" />
            
            <form onSubmit={handleSubmit} className="space-y-10 animate-in fade-in slide-in-from-right-4 duration-500">
              {activeStep === 1 && (
                <div className="space-y-8">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <User className="w-5 h-5 text-primary" />
                      <h3 className="text-2xl font-headline italic font-bold text-secondary uppercase tracking-tight">Personal Data</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">Enter your legal bio-data exactly as it appears on your identification.</p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Full Legal Name</Label>
                      <Input 
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        placeholder="e.g. Ama Boateng" 
                        value={formData.fullName}
                        onChange={e => setFormData({...formData, fullName: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Date of Birth</Label>
                      <Input 
                        type="date"
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        value={formData.dateOfBirth}
                        onChange={e => setFormData({...formData, dateOfBirth: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Phone Number</Label>
                      <Input 
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        placeholder="024 XXXXXXX" 
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Email Address</Label>
                      <Input 
                        type="email"
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        placeholder="ama@example.com" 
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Residential Address</Label>
                      <div className="relative">
                        <MapPin className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 pl-12 text-lg"
                          placeholder="Accra, Ghana" 
                          value={formData.address}
                          onChange={e => setFormData({...formData, address: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Occupation</Label>
                      <div className="relative">
                        <Briefcase className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 pl-12 text-lg"
                          placeholder="Current Role" 
                          value={formData.occupation}
                          onChange={e => setFormData({...formData, occupation: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeStep === 2 && (
                <div className="space-y-12">
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-primary" />
                        <h3 className="text-2xl font-headline italic font-bold text-secondary uppercase tracking-tight">Experience</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">Tell us about your background in the beauty industry.</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="prev-training" 
                          checked={formData.hasPreviousTraining}
                          onCheckedChange={(checked) => setFormData({...formData, hasPreviousTraining: !!checked})}
                        />
                        <Label htmlFor="prev-training" className="text-sm font-medium">Have you attended any beauty training before?</Label>
                      </div>
                      
                      {formData.hasPreviousTraining && (
                        <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                          <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">If yes, please specify:</Label>
                          <Textarea 
                            className="bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 min-h-[100px]"
                            placeholder="Detail your previous certifications or workshops..."
                            value={formData.previousTrainingDetails}
                            onChange={e => setFormData({...formData, previousTrainingDetails: e.target.value})}
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Industry Tenure</Label>
                        <Select value={formData.beautyExperience} onValueChange={val => setFormData({...formData, beautyExperience: val})}>
                          <SelectTrigger className="h-14 bg-muted/30 border-none rounded-xl text-lg">
                            <SelectValue placeholder="Years in industry" />
                          </SelectTrigger>
                          <SelectContent className="rounded-xl border-none shadow-xl">
                            <SelectItem value="beginner">Beginner (0-1 yr)</SelectItem>
                            <SelectItem value="intermediate">Intermediate (1-3 yrs)</SelectItem>
                            <SelectItem value="expert">Expert (3+ yrs)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Current Specialization</Label>
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                          placeholder="e.g. Skin Care, Bridal" 
                          value={formData.specialization}
                          onChange={e => setFormData({...formData, specialization: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6 pt-8 border-t border-primary/5">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <HeartHandshake className="w-5 h-5 text-primary" />
                        <h3 className="text-2xl font-headline italic font-bold text-secondary uppercase tracking-tight">Emergency Contact</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">Who should we contact in case of an emergency?</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Name</Label>
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl text-lg"
                          placeholder="Contact Name" 
                          value={formData.emergencyContactName}
                          onChange={e => setFormData({...formData, emergencyContactName: e.target.value})}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Relationship</Label>
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl text-lg"
                          placeholder="e.g. Spouse, Parent" 
                          value={formData.emergencyContactRelationship}
                          onChange={e => setFormData({...formData, emergencyContactRelationship: e.target.value})}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Phone Number</Label>
                        <Input 
                          className="h-14 bg-muted/30 border-none rounded-xl text-lg"
                          placeholder="Contact Phone" 
                          value={formData.emergencyContactPhone}
                          onChange={e => setFormData({...formData, emergencyContactPhone: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeStep === 3 && (
                <div className="space-y-8">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-primary" />
                      <h3 className="text-2xl font-headline italic font-bold text-secondary uppercase tracking-tight">Ghana Card Details</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">Verification is mandatory for all professional certifications.</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Ghana Card Number (ID)</Label>
                      <Input 
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg font-mono"
                        placeholder="GHA-XXXXXXXXX-X" 
                        value={formData.ghanaCardId}
                        onChange={e => setFormData({...formData, ghanaCardId: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Place of Issue</Label>
                      <Input 
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        placeholder="City/Region" 
                        value={formData.ghanaCardPlaceOfIssue}
                        onChange={e => setFormData({...formData, ghanaCardPlaceOfIssue: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Date of Issue</Label>
                      <Input 
                        type="date"
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        value={formData.ghanaCardDateOfIssue}
                        onChange={e => setFormData({...formData, ghanaCardDateOfIssue: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Expiry Date</Label>
                      <Input 
                        type="date"
                        className="h-14 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20 text-lg"
                        value={formData.ghanaCardExpiryDate}
                        onChange={e => setFormData({...formData, ghanaCardExpiryDate: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeStep === 4 && (
                <div className="space-y-10">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" />
                      <h3 className="text-2xl font-headline italic font-bold text-secondary uppercase tracking-tight">Payment & Declaration</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">Finalize your registration and sign the legal declaration.</p>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                    <div className="space-y-8">
                      <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 space-y-6">
                        <div className="flex items-center gap-2 text-primary">
                          <Info className="w-5 h-5" />
                          <p className="text-xs font-bold uppercase tracking-widest">Payment Information</p>
                        </div>
                        <div className="space-y-4">
                          <div className="space-y-1">
                            <p className="text-[10px] font-bold uppercase text-muted-foreground flex items-center gap-2">
                              <CreditCard className="w-3 h-3" /> Bank Transfer
                            </p>
                            <div className="text-xs space-y-0.5 text-secondary">
                              <p>Bank: <span className="font-bold">Ecobank</span></p>
                              <p>Branch: <span className="font-bold">A&C Mall Branch</span></p>
                              <p>Account: <span className="font-bold">Sawdatu Fuseini</span></p>
                              <p>Number: <span className="font-bold font-mono">1441002636952</span></p>
                            </div>
                          </div>
                          <div className="h-px bg-primary/10" />
                          <div className="space-y-1">
                            <p className="text-[10px] font-bold uppercase text-muted-foreground flex items-center gap-2">
                              <Smartphone className="w-3 h-3" /> Mobile Money
                            </p>
                            <div className="text-xs space-y-0.5 text-secondary">
                              <p>MOMO Number: <span className="font-bold">0206352077</span></p>
                              <p>Name: <span className="font-bold">Sawdatu Fuseini</span></p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Amount Deposited (GH₵)</Label>
                        <Input 
                          type="number"
                          className="h-14 bg-white border-2 border-primary/20 rounded-xl focus:border-primary text-2xl font-bold font-headline"
                          value={formData.amountPaid || ''}
                          onChange={e => setFormData({...formData, amountPaid: Number(e.target.value)})}
                          required
                        />
                        <p className="text-xs font-bold text-secondary italic">Remaining Balance: GH₵ {balanceDue.toLocaleString()}</p>
                      </div>

                      <div className="space-y-4">
                        <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Transaction ID / Reference</Label>
                        <div className="flex gap-3">
                          <div className="relative flex-1">
                            <Input 
                              className="h-14 bg-muted/30 border-none rounded-xl pr-12 text-lg font-mono"
                              placeholder="Reference ID"
                              value={formData.paymentReference}
                              onChange={e => setFormData({...formData, paymentReference: e.target.value})}
                              required
                            />
                            {isProcessingAI && <Loader2 className="absolute right-4 top-4.5 w-5 h-5 animate-spin text-primary" />}
                          </div>
                          <Label htmlFor="screenshot-upload" className="cursor-pointer">
                            <div className="bg-primary text-white h-14 w-14 rounded-xl flex items-center justify-center hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all active:scale-95">
                              <Smartphone className="w-6 h-6" />
                            </div>
                            <input 
                              id="screenshot-upload" 
                              type="file" 
                              className="hidden" 
                              accept="image/*"
                              onChange={handleFileUpload} 
                            />
                          </Label>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                      <div className="space-y-6">
                        <div className="bg-secondary p-6 rounded-2xl space-y-4 text-white">
                          <div className="flex items-center gap-2 text-primary">
                            <Award className="w-5 h-5" />
                            <p className="text-[10px] font-bold uppercase tracking-widest">Participant Declaration</p>
                          </div>
                          <p className="text-[11px] leading-relaxed text-white/70 italic">
                            I certify that the information provided in this form is accurate and complete. 
                            I agree to abide by the rules and requirements of the Viso Facial Treatment Training Program.
                          </p>
                          <div className="h-px bg-white/10" />
                          <div className="space-y-1">
                            <Label className="text-white/40 text-[8px] uppercase tracking-widest">Declaration Date</Label>
                            <Input 
                              type="date" 
                              className="bg-white/5 border-none h-10 text-xs text-white"
                              value={formData.declarationDate}
                              onChange={e => setFormData({...formData, declarationDate: e.target.value})}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground">Digital Signature</Label>
                          <div className="relative border-2 border-dashed border-primary/10 rounded-2xl bg-muted/10 h-40 group overflow-hidden">
                            <canvas 
                              ref={canvasRef}
                              width={600}
                              height={160}
                              className="w-full h-full cursor-crosshair touch-none"
                              onMouseDown={startSigning}
                              onMouseMove={draw}
                              onMouseUp={stopSigning}
                              onMouseOut={stopSigning}
                              onTouchStart={startSigning}
                              onTouchMove={draw}
                              onTouchEnd={stopSigning}
                            />
                            <div className="absolute top-2 right-2">
                              <Button type="button" variant="ghost" size="sm" onClick={handleSignatureClear} className="text-[9px] uppercase font-bold text-destructive hover:bg-destructive/10 rounded-full h-7 px-3">
                                Reset
                              </Button>
                            </div>
                            {!formData.signature && (
                              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
                                <p className="text-xs font-headline italic">Sign to attest</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-4 pt-6">
                {activeStep > 1 && (
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveStep(prev => prev - 1)}
                    className="h-16 flex-1 rounded-2xl border-primary/10 text-secondary font-headline italic text-lg"
                  >
                    <ChevronLeft className="w-5 h-5 mr-2" /> Previous
                  </Button>
                )}
                <Button 
                  type="submit" 
                  disabled={isSubmitting || (activeStep === TOTAL_STEPS && !formData.signature) || isProcessingAI}
                  className="h-16 flex-[2] rounded-2xl bg-primary hover:bg-primary/90 text-white font-headline italic text-2xl shadow-xl shadow-primary/20 transition-all hover:translate-y-[-2px] active:translate-y-[0px]"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-6 h-6 animate-spin mr-3" />
                  ) : activeStep < TOTAL_STEPS ? (
                    <>Next Step <ChevronRight className="w-6 h-6 ml-3" /></>
                  ) : (
                    <>Confirm & Register <Sparkles className="w-6 h-6 ml-3" /></>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </Card>
      
      <div className="text-center text-muted-foreground/40 text-xs flex flex-col items-center gap-4">
        <p className="uppercase tracking-[0.4em]">VisoRegistry Luxury Protocol v3.0</p>
      </div>
    </div>
  );
}
