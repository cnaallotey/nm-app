
import RegistrationForm from '@/components/RegistrationForm';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Settings, Sparkles } from 'lucide-react';
import { PlaceHolderImages } from '@/app/lib/placeholder-images';

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-beauty');

  return (
    <main className="min-h-screen bg-background selection:bg-primary/20 overflow-x-hidden">
      {/* Navigation */}
      <nav className="border-b border-primary/10 bg-white/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-headline font-bold shadow-lg shadow-primary/20">V</div>
            <span className="font-headline text-2xl font-bold tracking-tighter text-secondary italic">VisoRegistry</span>
          </div>
          <div className="flex gap-4 items-center">
            <Link href="/admin">
              <Button variant="ghost" className="gap-2 font-headline italic text-primary hover:text-primary hover:bg-primary/5 rounded-full px-6">
                <Settings className="w-4 h-4" /> Admin Portal
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative h-[40vh] md:h-[50vh] overflow-hidden">
        <Image
          src={heroImage?.imageUrl || 'https://picsum.photos/seed/beauty1/1200/600'}
          alt="Hero"
          fill
          className="object-cover brightness-[0.4]"
          priority
          data-ai-hint="professional makeup"
        />
        <div className="absolute inset-0 flex items-center justify-center text-center p-6">
          <div className="max-w-4xl space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <span className="text-xs font-bold uppercase tracking-[0.6em] text-primary-foreground/80">Est. 2024</span>
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-5xl md:text-7xl font-headline italic font-bold text-white leading-tight">
              Elegance in Digital <br /> Registration
            </h1>
            <p className="text-white/70 font-body text-lg max-w-xl mx-auto tracking-wide">
              Secure your place in the most prestigious beauty certification program in Ghana.
            </p>
            <div className="h-1 w-24 bg-primary mx-auto rounded-full shadow-[0_0_15px_rgba(var(--primary),0.5)]" />
          </div>
        </div>
      </div>

      <div className="relative -mt-16 z-10">
        <RegistrationForm />
      </div>
      
      <footer className="py-20 border-t border-primary/10 bg-white/50 backdrop-blur-sm mt-20">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="text-center md:text-left space-y-2">
            <p className="font-headline font-bold text-secondary italic text-2xl">VisoRegistry</p>
            <p className="text-xs text-muted-foreground uppercase tracking-[0.4em] font-bold">The Gold Standard of Management</p>
          </div>
          <div className="flex flex-col items-center md:items-end gap-2 text-xs text-muted-foreground uppercase tracking-widest">
            <p>&copy; {new Date().getFullYear()} VisoRegistry Concierge</p>
            <p>Accra • Kumasi • London</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
