
'use client';

import AdminConsole from '@/components/AdminConsole';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ChevronLeft, LogOut, Loader2 } from 'lucide-react';
import { useAuth, useUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { signOut } from 'firebase/auth';

export default function AdminPage() {
  const auth = useAuth();
  const { user, loading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    router.push('/login');
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#faf9f6]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[#faf9f6]">
      <nav className="border-b border-primary/10 bg-white/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2 font-headline italic text-primary hover:bg-primary/5 rounded-full">
              <ChevronLeft className="w-4 h-4" /> Back to Registration
            </Button>
          </Link>
          <div className="flex items-center gap-6">
            <span className="font-headline text-lg font-bold tracking-tight text-secondary italic hidden md:inline">VisoRegistry Admin</span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleLogout}
              className="gap-2 border-primary/20 text-primary rounded-full hover:bg-primary/5"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </Button>
          </div>
        </div>
      </nav>
      
      <AdminConsole />
    </main>
  );
}
