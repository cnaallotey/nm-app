
'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { useAuth, useUser } from '@/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, ShieldCheck, ArrowRight, Lock } from 'lucide-react';
import Link from 'next/link';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const auth = useAuth();
  const { user, loading: userLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (user && !userLoading) {
      router.push('/admin');
    }
  }, [user, userLoading, router]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth) return;
    
    setIsLoading(true);
    setError('');
    
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push('/admin');
    } catch (err: any) {
      setError('Invalid credentials. Please contact administration for access.');
      setIsLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-6 selection:bg-primary/20">
      <div className="w-full max-w-md space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="text-center space-y-2">
          <Link href="/">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white font-headline font-bold shadow-lg shadow-primary/20 mx-auto mb-6 hover:scale-110 transition-transform">V</div>
          </Link>
          <h1 className="text-4xl font-headline font-bold italic tracking-tight text-secondary">VisoRegistry</h1>
          <p className="text-xs uppercase tracking-[0.6em] text-muted-foreground font-bold">Secure Access Gateway</p>
        </div>

        <Card className="border-none shadow-2xl bg-white rounded-3xl overflow-hidden">
          <div className="h-2 bg-primary w-full" />
          <CardHeader className="space-y-1 pt-8">
            <CardTitle className="text-xl font-headline italic flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" /> Administrator Login
            </CardTitle>
            <CardDescription>Enter your high-level credentials to access the registrant data warehouse.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 pb-10">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Officer Email</Label>
                <Input 
                  type="email" 
                  placeholder="admin@visoregistry.com"
                  className="h-12 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground">Security Code</Label>
                <Input 
                  type="password" 
                  className="h-12 bg-muted/30 border-none rounded-xl focus:ring-2 focus:ring-primary/20"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              {error && (
                <p className="text-xs text-destructive font-bold animate-in fade-in slide-in-from-top-1">
                  {error}
                </p>
              )}

              <Button 
                type="submit" 
                disabled={isLoading}
                className="w-full h-12 bg-secondary hover:bg-secondary/90 text-white rounded-xl font-headline italic text-lg shadow-lg group transition-all"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Establish Secure Session <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </form>
            
            <div className="flex items-center justify-center gap-2 pt-4 opacity-40">
              <ShieldCheck className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase tracking-widest">AES-256 Bit Encryption Active</span>
            </div>
          </CardContent>
        </Card>
        
        <p className="text-center text-[10px] text-muted-foreground font-bold uppercase tracking-[0.3em]">
          &copy; {new Date().getFullYear()} VisoRegistry Concierge Security
        </p>
      </div>
    </main>
  );
}
