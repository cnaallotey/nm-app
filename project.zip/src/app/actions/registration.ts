'use server';

import { extractTransactionReference } from '@/ai/flows/transaction-reference-extraction';
import { Participant, RegistrationFormData } from '@/app/lib/types';

// Mock storage for demo purposes
// In a real app, this would use Firestore or another database
let storage: Participant[] = [];

export async function submitRegistration(data: RegistrationFormData): Promise<{ success: boolean; participant?: Participant }> {
  try {
    const balanceDue = data.trainingCost - data.amountPaid;
    const newParticipant: Participant = {
      ...data,
      id: Math.random().toString(36).substring(7),
      registrationDate: new Date().toISOString(),
      balanceDue: Math.max(0, balanceDue),
    };

    // In a real environment, you'd save to database here
    // For this prototype, we return the success and the created object
    return { success: true, participant: newParticipant };
  } catch (error) {
    console.error('Registration failed:', error);
    return { success: false };
  }
}

export async function processPaymentScreenshot(dataUri: string): Promise<{ reference: string }> {
  try {
    const result = await extractTransactionReference({ paymentScreenshot: dataUri });
    return { reference: result.transactionReference };
  } catch (error) {
    console.error('AI Extraction failed:', error);
    return { reference: 'Not Found' };
  }
}

export async function getRegistrants(): Promise<Participant[]> {
  // Mock data generation for admin view
  return [
    {
      id: '1',
      fullName: 'Akua Mensah',
      email: 'akua@example.com',
      phone: '0244123456',
      address: 'East Legon, Accra',
      ghanaCardId: 'GHA-723456789-1',
      beautyExperience: '3 Years',
      specialization: 'Bridal Makeup',
      emergencyContactName: 'Kofi Mensah',
      emergencyContactPhone: '0244987654',
      trainingCost: 3500,
      amountPaid: 3500,
      balanceDue: 0,
      paymentReference: 'TXN882736',
      registrationDate: new Date().toISOString(),
      signature: '',
    },
    {
      id: '2',
      fullName: 'Abena Osei',
      email: 'abena@example.com',
      phone: '0555987654',
      address: 'Kumasi, Ashanti',
      ghanaCardId: 'GHA-918273645-0',
      beautyExperience: '1 Year',
      specialization: 'Skin Care',
      emergencyContactName: 'Ama Osei',
      emergencyContactPhone: '0555123456',
      trainingCost: 3500,
      amountPaid: 500,
      balanceDue: 3000,
      paymentReference: 'MOMO-918273',
      registrationDate: new Date().toISOString(),
      signature: '',
    }
  ];
}
