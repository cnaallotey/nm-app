export interface Participant {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  address: string;
  dateOfBirth: string;
  occupation: string;
  ghanaCardId: string;
  ghanaCardDateOfIssue: string;
  ghanaCardPlaceOfIssue: string;
  ghanaCardExpiryDate: string;
  hasPreviousTraining: boolean;
  previousTrainingDetails: string;
  beautyExperience: string;
  specialization: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  emergencyContactRelationship: string;
  trainingCost: number;
  amountPaid: number;
  balanceDue: number;
  paymentMethod: 'Cash' | 'Mobile Money' | 'Bank Transfer' | 'Other';
  otherPaymentMethod?: string;
  paymentReference: string;
  registrationDate: string;
  signature: string; // Base64 signature
  declarationDate: string;
}

export type RegistrationFormData = Omit<Participant, 'id' | 'registrationDate' | 'balanceDue'>;
