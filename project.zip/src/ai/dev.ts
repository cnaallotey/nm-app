import { config } from 'dotenv';
config();

import '@/ai/flows/transaction-reference-extraction.ts';