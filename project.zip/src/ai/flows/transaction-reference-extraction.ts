'use server';
/**
 * @fileOverview A Genkit flow to extract transaction references from payment screenshots.
 *
 * - extractTransactionReference - A function that handles the extraction of transaction references from payment screenshots.
 * - TransactionReferenceExtractionInput - The input type for the extractTransactionReference function.
 * - TransactionReferenceExtractionOutput - The return type for the extractTransactionReference function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const TransactionReferenceExtractionInputSchema = z.object({
  paymentScreenshot: z
    .string()
    .describe(
      "A payment screenshot (MOMO or Bank Transfer), as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type TransactionReferenceExtractionInput = z.infer<typeof TransactionReferenceExtractionInputSchema>;

const TransactionReferenceExtractionOutputSchema = z.object({
  transactionReference: z
    .string()
    .describe('The extracted transaction reference from the payment screenshot. If no reference is found, return "Not Found".'),
});
export type TransactionReferenceExtractionOutput = z.infer<typeof TransactionReferenceExtractionOutputSchema>;

export async function extractTransactionReference(
  input: TransactionReferenceExtractionInput
): Promise<TransactionReferenceExtractionOutput> {
  return transactionReferenceExtractionFlow(input);
}

const transactionReferenceExtractionPrompt = ai.definePrompt({
  name: 'transactionReferenceExtractionPrompt',
  input: {schema: TransactionReferenceExtractionInputSchema},
  output: {schema: TransactionReferenceExtractionOutputSchema},
  prompt: `You are an AI assistant specialized in extracting transaction references from payment screenshots.
Analyze the provided image of a payment screenshot (either Mobile Money (MOMO) or Bank Transfer).
Your task is to identify and extract the unique transaction reference, transaction ID, reference number, or similar identifier.
Return only the extracted reference in the 'transactionReference' field. If multiple references are present, extract the primary one associated with the payment.
If you cannot find a clear transaction reference, set the 'transactionReference' field to "Not Found".

Payment Screenshot: {{media url=paymentScreenshot}}`,
});

const transactionReferenceExtractionFlow = ai.defineFlow(
  {
    name: 'transactionReferenceExtractionFlow',
    inputSchema: TransactionReferenceExtractionInputSchema,
    outputSchema: TransactionReferenceExtractionOutputSchema,
  },
  async (input) => {
    const {output} = await transactionReferenceExtractionPrompt(input);
    return output!;
  }
);
