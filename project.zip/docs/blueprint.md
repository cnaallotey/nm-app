# **App Name**: VisoRegistry

## Core Features:

- Digital Registration Engine: A comprehensive online form capturing participant details, beauty experience, emergency contacts, and Ghana Card IDs precisely as seen on the physical document.
- Registrant Data Warehouse: Integration with a central database to securely store and retrieve every submitted application for administrative management.
- AI Transaction Assistant: A feature powered by an AI tool to automatically parse payment screenshots (MOMO or Bank Transfer) to extract and verify transaction references.
- Admin Management Console: A secure view for the program organizers to browse, search, and download the data of people who have registered.
- Smart Balance Calculator: A dynamic interface element that instantly calculates and displays 'Balance Due' as users enter their 'Amount Paid'.
- Digital Signature Capture: A dedicated section for the Participant Declaration that supports electronic signature inputs for official certification.
- Automated Digital Receipt Generator: Automatically generates a downloadable 'Student Copy' receipt upon completion, styled with a digital tear-off slip design containing payment confirmation and training details.

## Style Guidelines:

- Primary color: Sophisticated Regal Gold (#B7952F) for an upscale, professional branding feel.
- Background color: Soft Ivory Pearl (#F3F1ED) to maintain readability while keeping a premium look.
- Accent color: Deep Umber (#822F10) for strong hierarchy in headlines and primary calls to action.
- Headline font: 'Playfair' (serif) for elegance; Body and form labels: 'PT Sans' (sans-serif) for modern clarity.
- Thin-line monochrome icons for 'Payment', 'Participant Details', and 'ID Card' to mirror physical form iconography.
- Two-column grid layout for desktop with a horizontal 'TEAR HERE' dotted line divider for the digital receipt section.
- Graceful fade-in transitions for form sections as the user scrolls to ensure the process feels high-end.