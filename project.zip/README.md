# VisoRegistry | Digital Registration Engine

This is a premium participant registration and data management system built with Next.js, Firebase, and Genkit AI.

## Local Development

If you have downloaded this project folder, follow these steps to run it on your computer:

1. **Install Dependencies**:
   Open your terminal in the project folder and run:
   ```bash
   npm install
   ```

2. **Set Up Environment Variables**:
   Create a `.env.local` file in the root directory and add your Firebase and Google AI keys:
   ```env
   NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
   GOOGLE_GENAI_API_KEY=your_genai_key
   ```

3. **Run the Development Server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:9002](http://localhost:9002) in your browser.

## How to Push to GitHub

To host your code on GitHub:

1. **Initialize Git**: `git init`
2. **Add Files**: `git add .`
3. **Commit**: `git commit -m "Initial commit: VisoRegistry Setup"`
4. **Link and Push**:
   - Create a new repo on GitHub.
   - `git remote add origin <YOUR_REPO_URL>`
   - `git branch -M main`
   - `git push -u origin main`

## Hosting on Netlify

1. Connect your GitHub repo to Netlify.
2. Add your environment variables in the Netlify Dashboard (**Site settings > Environment variables**).
3. Deploy!

---
© 2024 VisoRegistry Concierge Service